package com.example.weight_app_3;

import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;
import android.text.TextPaint;
import android.util.Log;
import android.os.Build;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;

import java.lang.annotation.Target;
import java.util.List;

public class weight_app_database extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight_app.db";
    private static final int VERSION=2;
    private static weight_app_database mDatabase;
    public enum SortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC };
    public static weight_app_database getInstance(Context context) {
        if (mDatabase == null) {
            mDatabase = new weight_app_database(context);
        }
        return mDatabase;
    }
    private weight_app_database(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /*public weight_app_database (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }*/

    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "username";
        private static final String COL_PASSWORD = "password";
    }
    private static final class DailyTable {
        private static final String TABLE = "daily_weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }
    private static final class TargetTable {
        private static final String TABLE = "target_weight";
        private static final String COL_ID = "_id";
        private static final String COL_TARGET = "target";
    }

    @Override
    public void onCreate (SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USER + " text, " +
                LoginTable.COL_PASSWORD + " text)");
        db.execSQL("create table " + DailyTable.TABLE + " (" +
                DailyTable.COL_ID + " integer primary key autoincrement, " +
                DailyTable.COL_DATE + " text, " +
                DailyTable.COL_WEIGHT + " text)");
        db.execSQL("create table " + TargetTable.TABLE + " ( " +
                TargetTable.COL_ID + " integer primary key autoincrement, " +
                TargetTable.COL_TARGET + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + DailyTable.TABLE);
        db.execSQL("drop table if exists " + TargetTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            }
            else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }
    // add user function
    public boolean addUser (User user){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USER, user.getUser());
        values.put(LoginTable.COL_PASSWORD, user.getPassword());
        long id = db.insert(LoginTable.TABLE, null, values);
        user.setId(id);
        return id != -1;
    }
    // validate user function
    // SOURCE: https://stackoverflow.com/questions/5202775/using-sqlite-to-validate-logins-in-android
    public int validateUser (String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] variables = new String[]{username, password};
        String sql = "select * from " + LoginTable.TABLE + " where " + LoginTable.COL_USER + " = ? and "
                + LoginTable.COL_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});
        int i = 0;
        i = cursor.getCount();
        if (!cursor.moveToFirst()) { return -1; }
        else { return 1; }
        /*try {
            int i = 0;
            Cursor c = null;
            c = db.rawQuery("select * from LOGIN_TABLE where username = ? and password = ?", variables);
            c.moveToFirst();
            i = c.getCount();
            c.close();
            return i;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return 0;*/
    }
    // read the username
    public String getUserName(String id){
        return id;
    }
    // update user if able
    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USER, user.getUser());
        values.put(LoginTable.COL_PASSWORD, user.getPassword());
        db.update(LoginTable.TABLE, values, LoginTable.COL_USER +
                " = ?", new String[] { user.getUser() });
        db.update(LoginTable.TABLE, values, LoginTable.COL_PASSWORD +
                " = ?", new String[] { user.getPassword() });
    }
    // delete a user
    public void deleteUser (User user) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(LoginTable.TABLE, LoginTable.COL_USER +
                " = ?", new String[] { user.getUser() });
    }
    // add a target weight
    public boolean addTarget (TargetWeight target) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TargetTable.COL_TARGET, target.getWeight());
        long id = db.insert(TargetTable.TABLE, null, values);
        target.setId(id);
        return id != -1;
    }
    // update a target weight
    public void updateTarget(TargetWeight target) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TargetTable.COL_TARGET, target.getWeight());
        db.update(TargetTable.TABLE, values, TargetTable.COL_ID +
                " = ?", new String[] { "1" });
    }
    public TargetWeight getTargetWeight() {
        TargetWeight targetWeight = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TargetTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            targetWeight = new TargetWeight();
            targetWeight.setId(cursor.getInt(0));
            targetWeight.setWeight(cursor.getString(1));
        }
        return targetWeight;
    }
    // not giving the option to delete a target weight because they must have one
    // add a daily weight record
    public boolean addDailyWeight (DailyWeight daily) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyTable.COL_WEIGHT, daily.getWeight());
        values.put(DailyTable.COL_DATE, daily.getDate());
        long id = db.insert(DailyTable.TABLE, null, values);
        daily.setId(id);
        return id != -1;
    }
    // update a daily weight
    public void updateDaily (DailyWeight daily) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyTable.COL_WEIGHT, daily.getWeight());
        values.put(DailyTable.COL_DATE, daily.getDate());
        db.update(DailyTable.TABLE, values, DailyTable.COL_DATE +
                " = ?", new String[] { daily.getDate() });
        db.update(DailyTable.TABLE, values, DailyTable.COL_WEIGHT +
                " = ?", new String[] { daily.getWeight() });
    }
    public DailyWeight getSingleDailyWeight() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM dd, yyyy");
        DailyWeight dailyWeight = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + DailyTable.TABLE + " order by " + DailyTable.COL_DATE + " DESC Limit 1";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            dailyWeight = new DailyWeight();
            dailyWeight.setId(cursor.getInt(0));
            dailyWeight.setWeight(cursor.getString(1));
            dailyWeight.setWeight(cursor.getString(2));
        }
        return dailyWeight;
    }
    public List<DailyWeight> getDailyWeights() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM dd, yyyy");
        List<DailyWeight> dailyWeights = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + DailyTable.TABLE + " order by " + DailyTable.COL_DATE + " DESC";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()){
            do {
                DailyWeight dailyWeight = new DailyWeight();
                dailyWeight.setDate(cursor.getString(1));
                dailyWeight.setWeight(cursor.getString(2));
                dailyWeights.add(dailyWeight);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dailyWeights;
    }

    // delete a daily weight record
    public void deleteDaily (DailyWeight daily) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(DailyTable.TABLE, DailyTable.COL_DATE +
                " = ?", new String[] { daily.getDate() });
    }

}
