package com.example.weight_app_3;

public class TargetWeight {
    private long mId;
    private String mTargetWeight;

    public TargetWeight() {}

    public TargetWeight(String tWeight) {
        //mId = id;
        mTargetWeight = tWeight;
    }
    public void setWeight(String tWeight) { mTargetWeight = tWeight; }
    public String getWeight() { return mTargetWeight; }
    public long getId() { return mId; }
    public void setId(long id) { mId = id; }
}